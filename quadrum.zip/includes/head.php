<!DOCTYPE html>
<html>


<head>
    <meta charset="utf-8">
    <title>Quadrum Steam Motor</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Stylesheets -->
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- Font Icon -->
    <link href="css/stroke-gap-icons.css" rel="stylesheet">
    <link href="css/flaticon.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/icofont.css" rel="stylesheet">
    <!-- Fancybox -->
    <link href="css/jquery.fancybox.css" rel="stylesheet">
    <!-- Revolution Slider -->
    <link href="css/revolution-slider.css" rel="stylesheet">
    <!-- Owl Carousel -->
    <link href="css/owl.carousel.css" rel="stylesheet">
    <!-- Main CSS -->
    <link href="main-style.css" rel="stylesheet">
    <!-- Responsive -->
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>