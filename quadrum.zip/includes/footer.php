  <!--Section::Footer-->
  <footer id="footer" class="main-footer">
      <div class="container ptn">
          <div class="row pt60 pb40">

          </div>
          <div class="row clearfix">
              <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="footer-1"> <a href="#">

                          <img class="img-responsive" src="images/logo/logo.png" alt="" title="Business">
                      </a>
                      <p>Since 2008, company have been researching, designing, developing, prototyping, and testing, the vapour pressure rotary piston steam engine "STEAM MOTOR" .</p>

                  </div>
              </div>

              <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="footer-3">
                      <h4>Contact us</h4>
                      <p><span>Address :</span> <br>
                          Pohjantie 62, 70940 Jännevirta</p>
                      <p><span>Call Us :</span> <br>
                          +358 40 022 3313</p>
                      <p><span>Email :</span> <br>
                          thomas.commondt@gmail.com </p>
                  </div>
              </div>
              <!--Footer Column-->

              <style>
                  @media screen and (max-width: 600px) {
                      .map-container {
                          overflow: hidden;
                          padding: 5%;
                          padding-bottom: 20%;
                          display: none;
                      }

                      .map-container iframe {
                          width: 300px;
                          height: 300px;
                      }
                  }
              </style>

              <div class="col-md-3 col-sm-6 col-xs-12">
                  <div class="map-container">
                      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d906.7983952313213!2d27.859349739028257!3d62.96361481335889!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4684aef9aac66ebb%3A0xbf787f9e152fd40d!2sPohjantie%2062%2C%2070940%20Kuopio%2C%20Finland!5e0!3m2!1sen!2snp!4v1715712551541!5m2!1sen!2snp" width="600" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                  </div>

              </div>
          </div>
      </div>
      <!--Copyright-->
      <div class="copyright"><a target="_blank" href="/">&copy; Copyright QUADRUM Steam Motor Oy Ab Ltd. 2008-<?php echo date('Y') ?> </a></div>
  </footer>
  <!--Section::Footer End -->