  <!-- Main Header / Style One-->
  <header class="main-header header-style-two">
      <!--Header-Main Box-->
      <div class="header-mainbox style_3">
          <div class="container ptn pbn">
              <div class="clearfix">
                  <div class="logo-box">
                      <div class="logo"> <a href="index.php"><img class="img-responsive" src="images/logo/logo.png" alt="" title="Business"></a> </div>
                      <!-- <div class="logo"> <a href="/">
                              <h1 class="text-white text-center">QUADRUM</h1>
                              <h3 class="text-center" style="color:#F6A210; font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">Steam Motor Finland</h3>
                          </a> 
                        </div> -->
                  </div>
                  <div class="outer-box clearfix">
                      <!-- Main Menu -->
                      <nav class="main-menu logo-outer">
                          <div class="navbar-header">
                              <!-- Toggle Button -->
                              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                          </div>
                          <div class="navbar-collapse collapse clearfix">
                              <ul class="navigation clearfix">
                                  <li class="current dropdown"> <a href="#home">Home</a>

                                  </li>
                                  <li class="dropdown"> <a href="#about-us">About Us</a>

                                  </li>

                                  <li class="dropdown"><a href="#quadram">QUADRUM</a>

                                  </li>
                                  <li class="dropdown"><a target="_blank" href="https://steammotor.blogspot.com/2009/">Our History</a>

                                  </li>
                                  <li class="dropdown"><a href="#gallery">Gallery</a>

                                  </li>
                                  <li class="dropdown"><a href="#footer">Contact Us</a>

                                  </li>

                              </ul>
                          </div>
                      </nav>
                      <!-- Main Menu End-->
                  </div>
              </div>
          </div>
      </div>
      <!--Header Main Box End-->
  </header>
  <!--End Main Header -->