<!-- Slider::Section Start-->
<section id="home" class="main-slider style_2">
    <div class="tp-banner-container">
        <div class="tp-banner">
            <ul>
                <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/slider/11.jpg" data-saveperformance="off" data-title="Business Coaching"> <img src="images/slider/11.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">
                    <div class="tp-caption lfb tp-resizeme" data-x="left" data-hoffset="15" data-y="center" data-voffset="0" data-speed="1500" data-start="750" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="big-title text-uppercase">
                            <h1>With <br> <span>Quadrum</span></h1>
                        </div>
                    </div>

                    <div class="tp-caption lfb tp-resizeme" data-x="left" data-hoffset="20" data-y="center" data-voffset="120" data-speed="1500" data-start="1000" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="">
                            <p>"The patented rotary piston steam motor functions as a power plant machine. It efficiently <br> onverts thermal energy into mechanical energy. This innovative technology enhances power generation <br>capabilities. Its design optimizes performance and reduces energy loss.."</p>
                        </div>
                    </div>

                    <!-- <div class="tp-caption lfb tp-resizeme" data-x="left" data-hoffset="20" data-y="center" data-voffset="200" data-speed="1500" data-start="1000" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="link-btn"><a href="#" class="btn theme-btn">QUADRAM</a></div>
                    </div> -->
                </li>
                <li data-transition="slideup" data-slotamount="1" data-masterspeed="1000" data-thumb="images/slider/22.jpg" data-saveperformance="off" data-title="We Works With"> <img src="images/slider/22.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">
                    <div class="tp-caption lfb tp-resizeme" data-x="right" data-hoffset="-15" data-y="center" data-voffset="0" data-speed="1500" data-start="1000" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="big-title text-right">
                            <h1>QUADRUM'S <br><span> Thermal Efficiency</span></h1>
                        </div>
                    </div>


                    <div class="tp-caption lfb tp-resizeme" data-x="right" data-hoffset="-15" data-y="center" data-voffset="120" data-speed="1500" data-start="1000" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="text-right">
                            <p>"QUADRUM excels in thermal power plants using solar energy, renewable energy, or waste heat. Its <br> patented rotary piston steam motor optimizes performance and reduces energy loss. This <br>innovation significantly boosts power generation capabilities."</p>
                        </div>
                    </div>
                    <!-- <div class="tp-caption lfb tp-resizeme" data-x="right" data-hoffset="-15" data-y="center" data-voffset="200" data-speed="1500" data-start="1500" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="link-btn"><a href="#" class="btn theme-btn">View Profile</a></div>
                    </div> -->
                </li>
                <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/slider/33.jpg" data-saveperformance="off" data-title="The Customer"> <img src="images/slider/33.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">
                    <div class="tp-caption lfb tp-resizeme" data-x="left" data-hoffset="15" data-y="center" data-voffset="0" data-speed="1500" data-start="1000" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="big-title">
                            <h1>Quadrum <br>
                                <span>Expansion</span>
                            </h1>
                        </div>
                    </div>

                    <div class="tp-caption lfb tp-resizeme" data-x="left" data-hoffset="20" data-y="center" data-voffset="120" data-speed="1500" data-start="1000" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="">
                            <p>"SHOPSTICATED for QUADRUM plant, QUADRUMSTEAM@ expands in three locations. These locations handle <br>twelve works each. This growth demonstrates QUADRUM's efficient and versatile application."</p>
                        </div>
                    </div>
                    <!-- <div class="tp-caption lfb tp-resizeme" data-x="left" data-hoffset="15" data-y="center" data-voffset="200" data-speed="1500" data-start="1500" data-easing="easeOutExpo" data-splitin="none" data-splitout="none" data-elementdelay="0.01" data-endelementdelay="0.3" data-endspeed="1200" data-endeasing="Power4.easeIn" style="z-index: 4; white-space: nowrap;">
                        <div class="link-btn"><a href="#" class="btn theme-btn">Our Project</a></div>
                    </div> -->
                </li>
            </ul>
            <div class="tp-bannertimer"></div>
        </div>
    </div>
</section>
<!-- Slider::Section End-->