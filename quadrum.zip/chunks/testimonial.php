<!--Section:: Testimonial-->
<section class="testimonial style_2">
    <div class="container">
        <div class="section-content">
            <div class="row">
                <div class="col-md-4">
                    <div class="testimonial_style_2">
                        <div class="item">
                            <div class="testimonial-item style_2">
                                <blockquote>
                                    <div class="testimonial-thumb pb20">
                                        <img class="img-circle" src="images/testimonial/4.jpg" alt="">
                                    </div>
                                    <cite>
                                        <span>Sharon K. Larsen</span>
                                    </cite>
                                    <p>Anyone who's working in manufacturing here should know they will have increased opportunities if we leave the European Union. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio repudiandae officiis molestiae perferendis.</p>
                                </blockquote>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-item style_2">
                                <blockquote>
                                    <div class="testimonial-thumb pb20">
                                        <img class="img-circle" src="images/testimonial/4.jpg" alt="">
                                    </div>
                                    <cite>
                                        <span>Sharon K. Larsen</span>
                                    </cite>
                                    <p>Anyone who's working in manufacturing here should know they will have increased opportunities if we leave the European Union. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio repudiandae officiis molestiae perferendis.</p>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="opsition">
                        <div class="rich-text">
                            <h2>Let's Grow<br>
                                <strong>Together</strong>
                            </h2>
                            <p class="text-white">Join our honor winning group, and appreciate an inventive, <br> dynamic and comprehensive culture concentrated on one objective.</p>
                            <a href="contact.html" class="btn theme-btn mt20">See Open careers</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!--Section:: Testimonial End -->