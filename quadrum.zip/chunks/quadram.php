<!--Featured Services-->
<section id="quadram" class="featured-services">
    <div class="container">
        <div class="section-title">
            <div class="row">
                <div class="col-md-8">
                    <div class="title-inner">
                        <div class="text">
                            <h2 class="small-line mb30">QUAD<span>RUM</span> </h2>
                            <h3>QUADRUM is a steam driven steam motor. It is a heart of CHP-Plant. It turns the generator. The piston of a QUADRUM is square-shaped. We concluded that the QUADRUM has an efficiency of around 55% after conducting several tests and calculations. </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Box Container-->
        <div class="container-box anim-5-all">
            <div class="col-lg-12 single-what-we-do clearfix">
                <div class="img-wrap">
                    <img src="images/what-we-do/1.jpg" alt="">

                </div>
                <div class="content">
                    <!-- <h2>Metal and Non - Metals</h2> -->
                    <p>With little moving components and low steam pressure, QUADRUM boasts exceptional efficiency. While a steam turbine plant requires extremely high steam pressure, which necessitates sophisticated feed water treatment, no such water treatment is required for the QUADRUM. </p>
                    <!-- <a href="#">Read More</a> -->
                </div>
            </div>
            <div class="col-lg-12 single-what-we-do clearfix content-left">
                <div class="img-wrap">
                    <img src="images/what-we-do/2.jpg" alt="">

                </div>
                <div class="content">
                    <!-- <h2>Construction Materials</h2> -->
                    <p>Every 360 degrees of rotation, the steam inside the QUADRUM expands in two different places inside the cylinder. The piston does the task four times every revolution since it is square in shape. Therefore, each 360-degree turn of the piston's four sides plus the two working locations inside the cylinder equals twelve works per 360-degree turn.</p>
                    <!-- <a href="#">Read More</a> -->
                </div>
            </div>




        </div>
        <!--Box Container End-->

        <!-- Video Section -->
        <section id="videos" class="video-section">
            <div class="container">
                <div class="section-title">
                    <h2 class="small-line">Demonstration<span> Video</span> </h2>
                    <h3>
                        <p>
                            Four periodically increasing and decreasing spaces are formed between the walls of the square rotary piston and the housing walls.
                        </p>
                        <p>
                            The nest of the QUADRUM has two spaces connected by a flow passage above the centre and two spaces connected by a flow passage below the centre.
                        </p>
                        <p>
                            The rotation cycle of the motor is systematic so that when the upper chambers are filled, both lower chambers are emptied and when the lower chambers are filled, both upper chambers are emptied.
                        </p>
                    </h3>
                </div>
                <div class="row">

                    <div>
                        <div class="video-item">
                            <video width="100%" height="315" controls autoplay>
                                <source src="./assets/videos/q3.mp4" type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        </div>
                    </div>
                </div>

            </div>
            <div class="download text-center">
                <a href="" id="download-btn" class="btn-style-one">
                    <button style="color:white; background:#F6A210; padding:10px 50px; border-radius:20px;">Read more</button>
                </a>
            </div>
            <script>
                document.getElementById("download-btn").addEventListener("click", function() {
                    // Create a virtual link
                    var link = document.createElement('a');
                    link.href = 'assets/quadram.png'; // Replace 'path/to/your/image.jpg' with the actual path to your image
                    link.target = '_blank'; // Open in a new tab or window
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                });
            </script>
        </section>
    </div>
</section>