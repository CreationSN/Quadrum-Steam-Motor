  <!-- Portfolio::Section -->
  <section id="gallery" class="portfolio pb50 pt50  overlayer overlayer-black parallax" data-bg-image="images/bg/bg5.jpg">
      <div class="container pbn">
          <div class="section-title">
              <div class="row">
                  <div class="col-md-6 col-md-offset-3 text-center">
                      <h2 class="small-line-center text-white">OUR GALLERY</h2>
                  </div>
              </div>
          </div>
      </div>
      <div class="container ptn">
          <div class="section-wrap">
              <div class="row clearfix">
                  <div class="portfolio col-3 portfolio-masonry gutter-less mtn">
                      <div class="portfolio-item default-gallery-item style_2 item-one">
                          <div class="inner-box">
                              <!--Image Box-->
                              <figure class="image-box">
                                  <img src="images/gallery/m8.jpg" alt="" class="img-responsive">
                                  <a href="images/gallery/m8.jpg" class="lightbox-image image-link"><span class="icofont icofont-plus-circle"></span></a>
                              </figure>
                          </div>
                      </div>
                      <div class="portfolio-item default-gallery-item style_2 item-two">
                          <div class="inner-box">
                              <!--Image Box-->
                              <figure class="image-box">
                                  <img src="images/gallery/m1.jpg" alt="" class="img-responsive">
                                  <a href="images/gallery/m1.jpg" class="lightbox-image image-link"><span class="icofont icofont-plus-circle"></span></a>
                              </figure>
                              <!--Overlay Box-->
                          </div>
                      </div>
                      <div class="portfolio-item default-gallery-item style_2 item-one item-three">
                          <div class="inner-box">
                              <!--Image Box-->
                              <figure class="image-box">
                                  <img src="images/gallery/m3.jpg" alt="" class="img-responsive">
                                  <a href="images/gallery/m3.jpg" class="lightbox-image image-link"><span class="icofont icofont-plus-circle"></span></a>
                              </figure>
                              <!--Overlay Box-->
                          </div>
                      </div>
                      <div class="portfolio-item default-gallery-item style_2 item-four item-three">
                          <div class="inner-box">
                              <!--Image Box-->
                              <figure class="image-box">
                                  <img src="images/gallery/m4.jpg" alt="" class="img-responsive">
                                  <a href="images/gallery/m4.jpg" class="lightbox-image image-link"><span class="icofont icofont-plus-circle"></span></a>
                              </figure>
                              <!--Overlay Box-->
                          </div>
                      </div>
                      <div class="portfolio-item default-gallery-item style_2 item-one item-four">
                          <div class="inner-box">
                              <!--Image Box-->
                              <figure class="image-box">
                                  <img src="images/gallery/m5.jpg" alt="" class="img-responsive">
                                  <a href="images/gallery/m5.jpg" class="lightbox-image image-link"><span class="icofont icofont-plus-circle"></span></a>
                              </figure>
                              <!--Overlay Box-->
                          </div>
                      </div>
                      <div class="portfolio-item default-gallery-item style_2 item-one item-three">
                          <div class="inner-box">
                              <!--Image Box-->
                              <figure class="image-box">
                                  <img src="images/gallery/m9.jpg" alt="" class="img-responsive">
                                  <a href="images/gallery/m9.jpg" class="lightbox-image image-link"><span class="icofont icofont-plus-circle"></span></a>
                              </figure>
                              <!--Overlay Box-->
                          </div>
                      </div>
                  </div>
                  <!-- <div class="text-center"><a href="#" class="btn theme-btn mt40">View More </a></div> -->

              </div>
          </div>
      </div>
  </section>
  <!-- Portfolio::Section End -->