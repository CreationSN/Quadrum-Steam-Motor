<section id="about-us" class="about">
    <style>
        b {
            color: black;
        }
    </style>

    <div class="container pb60">
        <div class="row">
            <div class="col-md-6">
                <h2 class="text-uppercase small-line mb30">About Our <span class="text-theme-color">Company</span></h2>
                <h3>Steam Motor Oy Ab Ltd.</h3>
                <p> Since 2008, company have been researching, designing, developing, prototyping, and testing, the vapour pressure rotary piston steam motor <b>“QUADRUM”</b> . </p>
                <p>The company line of business is designing, manufacturing, maintaining, and retailing of power plants equipment and machinery. </p>


                <p><b>QUADRUM</b> is suitable for the small and medium-sized power plants due to its low energy consumption. The QUADRUM will be the hearth in a CHP-plant. Combined Heat and Power plant.</p>
                <!-- <div class="view_more">
                    <a href="#">Learn More <span class="icofont icofont-arrow-right"></span></a>
                </div> -->
            </div>
            <div class="col-md-6">
                <div class="single-img">
                    <img class="img-responsive" src="images/about/about.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>