    <!-- Section::Client -->
    <section class="client bg-color-f9">
        <div class="container pt40 pb40">
            <div class="section-content">
                <div class="row">
                    <div class="col-sm-10 co-sm-offset-1 col-md-10 col-md-offset-1">
                        <div class="clients-slider">
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/1-w.png"></div>
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/2-w.png"></div>
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/3-w.png"></div>
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/4-w.png"></div>
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/5-w.png"></div>
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/1-w.png"></div>
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/2-w.png"></div>
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/3-w.png"></div>
                            <!-- Logo item -->
                            <div class="item"><img alt="" src="images/client/1-w.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Section::Client End-->