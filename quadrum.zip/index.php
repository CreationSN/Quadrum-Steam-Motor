<?php
include 'includes/head.php';
?>

<body>
  <div class="page-wrapper">

    <?php
    include 'includes/preloader.php';
    include 'includes/navbar.php';
    include 'chunks/slider.php';
    include 'chunks/about-us.php';
    include 'chunks/quadram.php';
    include 'chunks/portfolio.php';
    // include 'chunks/testimonial.php';
    // include 'chunks/client.php';
    include 'includes/footer.php';
    ?>

  </div>
  <!--End pagewrapper-->

  <!--Scroll to top-->
  <div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icofont icofont-long-arrow-up"></span></div>
  <script src="js/jquery.js"></script>
  <script src="js/jquery-ui-1.11.4/jquery-ui.js"></script>
  <script src="js/revolution.min.js"></script>
  <script src="js/rev-custom.js"></script>
  <script src="js/all-jquery.js"></script>
  <script src="js/script.js"></script>
</body>

</html>